A Pen created at CodePen.io. You can find this one at http://codepen.io/GabbeV/pen/viAec.

 Generating a maze with a simple algorithm<br>
1. Find available directions
2. pick one at random
3. if no available directions, backtrack to last position
loop step 1 to 3 until back at start location